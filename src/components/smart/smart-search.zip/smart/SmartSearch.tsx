import { useEffect, useRef, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import {
  Sparkles,
  Mic,
  ArrowRight,
  MapPin,
  Calendar,
  Users,
  Wallet,
  Heart,
  PartyPopper,
  TreePine,
  Crown,
  Check,
} from "lucide-react";
import DatePicker, { DateRange } from "./DatePicker";
import PeopleSelector, { People, summarizePeople } from "./PeopleSelector";
import BudgetSlider, { formatBudgetShort } from "./BudgetSlider";

type Vibe = "romantic" | "party" | "chill" | "luxury" | null;

const VIBES: { id: NonNullable<Vibe>; label: string; icon: any; gradient: string }[] = [
  { id: "romantic", label: "Romantic", icon: Heart, gradient: "from-rose-500 to-pink-500" },
  { id: "party", label: "Party", icon: PartyPopper, gradient: "from-fuchsia-500 to-purple-500" },
  { id: "chill", label: "Chill", icon: TreePine, gradient: "from-emerald-500 to-teal-500" },
  { id: "luxury", label: "Luxury", icon: Crown, gradient: "from-amber-400 to-orange-500" },
];

const POPULAR_DESTINATIONS = ["Bali", "Goa", "Dubai", "Paris", "Tokyo", "Maldives", "Manali", "Santorini"];

const SUGGESTION_CHIPS = [
  "Beach getaway under ₹50K",
  "Romantic Paris in November",
  "Family trip to Bali",
  "Adventure in Manali",
];

const SmartSearch = () => {
  const navigate = useNavigate();

  // State
  const [destination, setDestination] = useState("");
  const [dates, setDates] = useState<DateRange>({ start: null, end: null });
  const [people, setPeople] = useState<People>({ adults: 2, children: 0 });
  const [budget, setBudget] = useState(50000);
  const [vibe, setVibe] = useState<Vibe>(null);

  // Flow control
  const [inputFocused, setInputFocused] = useState(false);
  const [activePanel, setActivePanel] = useState<"dates" | "people" | "budget" | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // Has the user committed to a destination? Trigger the wizard expansion.
  const expanded = destination.trim().length > 0;

  // Click outside to close active panel
  useEffect(() => {
    if (!activePanel) return;
    const onClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setActivePanel(null);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [activePanel]);

  // Build the query string and submit
  const submit = () => {
    if (!destination.trim()) return;
    const parts: string[] = [destination.trim()];
    const nights =
      dates.start && dates.end
        ? Math.round((dates.end.getTime() - dates.start.getTime()) / (1000 * 60 * 60 * 24))
        : 0;
    if (nights > 0) parts.push(`${nights} days`);
    const total = people.adults + people.children;
    if (total > 0) parts.push(`for ${total} ${total === 1 ? "person" : "people"}`);
    if (budget) parts.push(`under ${formatBudgetShort(budget).toLowerCase()}`);
    if (vibe) parts.push(vibe);
    const query = parts.join(" ");
    navigate(`/plan?q=${encodeURIComponent(query)}`);
  };

  // Quick stats for the "ready to go" state
  const completedFields =
    [
      destination.trim().length > 0,
      Boolean(dates.start && dates.end),
      people.adults > 0,
      budget > 0,
      Boolean(vibe),
    ].filter(Boolean).length;
  const ready = completedFields >= 1; // destination minimum

  return (
    <div ref={containerRef} className="mx-auto w-full max-w-3xl">
      {/* MAIN INPUT BAR */}
      <motion.div
        layout
        animate={{
          boxShadow: inputFocused || expanded
            ? "0 0 60px -10px rgba(212,168,106,0.4)"
            : "0 0 0px 0px rgba(0,0,0,0)",
        }}
        transition={{ duration: 0.3 }}
        className={`relative overflow-hidden rounded-full border p-1.5 backdrop-blur-xl transition-colors ${
          inputFocused || expanded
            ? "border-amber-400/50 bg-white/[0.06]"
            : "border-white/10 bg-white/[0.03]"
        }`}
      >
        <div className="flex items-center gap-2">
          <motion.div
            animate={{ rotate: expanded ? 0 : [0, -10, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, repeatDelay: 4 }}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-amber-700"
          >
            <Sparkles className="h-4 w-4 text-black" />
          </motion.div>

          <div className="flex flex-1 flex-col">
            <span className="px-1 text-[10px] uppercase tracking-[0.18em] text-amber-300/80">
              Tell Voya anything
            </span>
            <input
              type="text"
              value={destination}
              onChange={(e) => setDestination(e.target.value)}
              onFocus={() => setInputFocused(true)}
              onBlur={() => setInputFocused(false)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              placeholder="Where do you want to go?"
              className="bg-transparent px-1 py-0.5 text-base text-white outline-none placeholder:text-white/40"
              autoComplete="off"
            />
          </div>

          <button
            aria-label="Voice input"
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full text-white/60 transition hover:bg-white/5 hover:text-white"
          >
            <Mic className="h-4 w-4" />
          </button>
          <motion.button
            onClick={submit}
            disabled={!ready}
            whileTap={{ scale: 0.95 }}
            className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-amber-400 text-black transition hover:bg-amber-300 disabled:cursor-not-allowed disabled:opacity-40"
            aria-label="Submit"
          >
            <ArrowRight className="h-4 w-4" />
          </motion.button>
        </div>
      </motion.div>

      {/* SUGGESTION CHIPS — visible only before user starts typing */}
      <AnimatePresence>
        {!expanded && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4, height: 0 }}
            transition={{ duration: 0.25 }}
            className="mt-4 flex flex-wrap items-center justify-center gap-2"
          >
            <span className="text-[10px] uppercase tracking-[0.18em] text-white/40">Try:</span>
            {SUGGESTION_CHIPS.map((s) => (
              <button
                key={s}
                onClick={() => {
                  // Pull the destination out of the chip text
                  const dest = POPULAR_DESTINATIONS.find((d) => s.toLowerCase().includes(d.toLowerCase()));
                  setDestination(dest ?? s);
                }}
                className="rounded-full border border-white/10 bg-white/[0.02] px-3 py-1 text-xs text-white/60 transition hover:border-amber-400/30 hover:bg-amber-400/[0.04] hover:text-white"
              >
                {s}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* POPULAR DESTINATIONS — when input focused but empty */}
      <AnimatePresence>
        {inputFocused && !expanded && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ duration: 0.25 }}
            className="mt-4 rounded-3xl border border-white/10 bg-[#0c0c0c]/95 p-4 backdrop-blur-xl"
          >
            <p className="mb-2 text-[10px] uppercase tracking-[0.18em] text-white/40">
              Popular destinations
            </p>
            <div className="flex flex-wrap gap-1.5">
              {POPULAR_DESTINATIONS.map((d) => (
                <button
                  key={d}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    setDestination(d);
                  }}
                  className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.02] px-3 py-1.5 text-xs text-white/80 transition hover:border-amber-400/30 hover:bg-amber-400/[0.04]"
                >
                  <MapPin className="h-3 w-3 text-amber-400" />
                  {d}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* WIZARD — expands once user has a destination */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ opacity: 0, height: 0, marginTop: 0 }}
            animate={{ opacity: 1, height: "auto", marginTop: 16 }}
            exit={{ opacity: 0, height: 0, marginTop: 0 }}
            transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden"
          >
            <div className="space-y-4">
              {/* Field row — Date · People · Budget triggers */}
              <div className="grid gap-2 sm:grid-cols-3">
                <FieldTrigger
                  icon={Calendar}
                  label="When"
                  value={
                    dates.start && dates.end
                      ? `${formatRange(dates.start, dates.end)}`
                      : "Add dates"
                  }
                  filled={Boolean(dates.start && dates.end)}
                  active={activePanel === "dates"}
                  onClick={() => setActivePanel(activePanel === "dates" ? null : "dates")}
                />
                <FieldTrigger
                  icon={Users}
                  label="Who"
                  value={summarizePeople(people)}
                  filled={true}
                  active={activePanel === "people"}
                  onClick={() => setActivePanel(activePanel === "people" ? null : "people")}
                />
                <FieldTrigger
                  icon={Wallet}
                  label="Budget"
                  value={`Up to ${formatBudgetShort(budget)}`}
                  filled={true}
                  active={activePanel === "budget"}
                  onClick={() => setActivePanel(activePanel === "budget" ? null : "budget")}
                />
              </div>

              {/* Floating panel — only one open at a time */}
              <AnimatePresence mode="wait">
                {activePanel === "dates" && (
                  <DatePicker
                    key="dates"
                    value={dates}
                    onChange={setDates}
                    onClose={() => setActivePanel(null)}
                  />
                )}
                {activePanel === "people" && (
                  <PeopleSelector
                    key="people"
                    value={people}
                    onChange={setPeople}
                    onClose={() => setActivePanel(null)}
                  />
                )}
                {activePanel === "budget" && (
                  <BudgetSlider
                    key="budget"
                    value={budget}
                    onChange={setBudget}
                    onClose={() => setActivePanel(null)}
                  />
                )}
              </AnimatePresence>

              {/* Vibe selector — always visible */}
              <div className="rounded-3xl border border-white/10 bg-[#0c0c0c]/60 p-4 backdrop-blur-xl">
                <p className="mb-3 text-[10px] uppercase tracking-[0.18em] text-white/40">
                  What's the vibe?
                </p>
                <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                  {VIBES.map((v, i) => {
                    const Icon = v.icon;
                    const active = vibe === v.id;
                    return (
                      <motion.button
                        key={v.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.3, delay: i * 0.05 }}
                        onClick={() => setVibe(active ? null : v.id)}
                        className={`group relative overflow-hidden rounded-2xl border p-3 text-left transition ${
                          active
                            ? "border-white/20 bg-white/[0.06]"
                            : "border-white/10 bg-white/[0.02] hover:border-white/15"
                        }`}
                      >
                        <div
                          className={`absolute inset-0 bg-gradient-to-br opacity-0 transition-opacity ${v.gradient} ${
                            active ? "opacity-15" : "group-hover:opacity-10"
                          }`}
                        />
                        <div className="relative flex items-center gap-2">
                          <div
                            className={`grid h-7 w-7 place-items-center rounded-lg bg-gradient-to-br ${v.gradient}`}
                          >
                            <Icon className="h-3.5 w-3.5 text-white" />
                          </div>
                          <span className="text-sm text-white">{v.label}</span>
                          {active && (
                            <Check className="ml-auto h-4 w-4 text-emerald-300" />
                          )}
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* Big CTA */}
              <motion.button
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.2 }}
                onClick={submit}
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                className="group relative w-full overflow-hidden rounded-2xl bg-gradient-to-r from-amber-400 via-amber-300 to-amber-400 py-4 text-base font-bold uppercase tracking-[0.2em] text-black shadow-[0_20px_50px_-15px_rgba(212,168,106,0.6)]"
              >
                <span className="relative z-10 inline-flex items-center gap-3">
                  <Sparkles className="h-4 w-4" />
                  Plan my {destination.trim()} trip
                  <ArrowRight className="h-4 w-4 transition group-hover:translate-x-1" />
                </span>
                <span className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/40 to-transparent transition-transform duration-1000 group-hover:translate-x-full" />
              </motion.button>

              {/* Generated query preview */}
              <p className="text-center text-[11px] text-white/40">
                Query: <span className="italic text-white/60">"{buildQueryPreview(destination, dates, people, budget, vibe)}"</span>
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

// ---------- Helpers ----------

const FieldTrigger = ({
  icon: Icon,
  label,
  value,
  filled,
  active,
  onClick,
}: {
  icon: any;
  label: string;
  value: string;
  filled: boolean;
  active: boolean;
  onClick: () => void;
}) => (
  <button
    onClick={onClick}
    className={`flex items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
      active
        ? "border-amber-400/50 bg-amber-400/[0.06]"
        : filled
          ? "border-white/15 bg-white/[0.04] hover:border-white/25"
          : "border-white/10 bg-white/[0.02] hover:border-white/20"
    }`}
  >
    <div
      className={`grid h-9 w-9 shrink-0 place-items-center rounded-lg ${
        active ? "bg-amber-400/15 text-amber-300" : "bg-white/[0.04] text-white/70"
      }`}
    >
      <Icon className="h-4 w-4" />
    </div>
    <div className="min-w-0 flex-1">
      <p className="text-[10px] uppercase tracking-[0.18em] text-white/40">{label}</p>
      <p className="truncate text-sm text-white">{value}</p>
    </div>
  </button>
);

const formatRange = (start: Date, end: Date) => {
  const opts: Intl.DateTimeFormatOptions = { day: "numeric", month: "short" };
  const s = start.toLocaleDateString("en-GB", opts);
  const e = end.toLocaleDateString("en-GB", opts);
  return `${s} → ${e}`;
};

const buildQueryPreview = (
  destination: string,
  dates: DateRange,
  people: People,
  budget: number,
  vibe: Vibe
) => {
  const parts: string[] = [destination.trim() || "..."];
  if (dates.start && dates.end) {
    const nights = Math.round(
      (dates.end.getTime() - dates.start.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (nights > 0) parts.push(`${nights} days`);
  }
  const total = people.adults + people.children;
  parts.push(`for ${total} ${total === 1 ? "person" : "people"}`);
  parts.push(`under ${formatBudgetShort(budget).toLowerCase()}`);
  if (vibe) parts.push(vibe);
  return parts.join(" ");
};

export default SmartSearch;
