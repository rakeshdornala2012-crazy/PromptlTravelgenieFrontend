# Smart Search Wizard — Integration

Premium AI-assisted trip input flow. Replaces your existing input bar in
`Index.tsx` with a conversational wizard that expands inline as the user types.

## Files

```
SmartSearch.tsx       Main orchestrator — drop into src/components/
DatePicker.tsx        Range calendar — drop into src/components/
PeopleSelector.tsx    Adults/children stepper — drop into src/components/
BudgetSlider.tsx      Budget slider with presets — drop into src/components/
```

All four go in the same folder. Recommended: `src/components/smart/`

## How the UX flow works

1. **Idle state** — input bar visible alone, with suggestion chips below
   ("Beach getaway under ₹50K", etc.) and floating sparkle icon
2. **Focused state** — popular destinations panel slides in below the input
3. **Typing state** — user types "Bali" or clicks a popular chip → wizard
   expands with three trigger buttons (When · Who · Budget) plus a Vibe selector
4. **Picking** — clicking any trigger opens a floating panel (calendar / people
   stepper / budget slider). Click outside or press X to close.
5. **Complete** — big amber CTA button, plus a live query preview underneath
   ("Bali 5 days for 2 people under ₹50K romantic")
6. **Submit** — navigates to `/plan?q=<encoded query>`

## Wiring into your existing Index.tsx

**Step 1** — Drop the 4 files into `src/components/smart/`

**Step 2** — Open your existing `src/pages/Index.tsx` and find the line that
currently renders your input bar. It's probably something like:

```tsx
import PromptBar from "@/components/PromptBar";
// ...
<PromptBar />
```

Or it might be inline JSX. Find that input and replace with:

```tsx
import SmartSearch from "@/components/smart/SmartSearch";
// ...
<SmartSearch />
```

That's the only change to Index.tsx.

## Dependencies

Already in your project:
- `react-router-dom` — for `useNavigate()`
- `framer-motion` — for animations
- `lucide-react` — for icons

No new dependencies needed.

## Customization

### Popular destinations
Edit the `POPULAR_DESTINATIONS` array near the top of `SmartSearch.tsx`:
```tsx
const POPULAR_DESTINATIONS = ["Bali", "Goa", "Dubai", ...];
```

### Suggestion chips
Edit `SUGGESTION_CHIPS` in the same file:
```tsx
const SUGGESTION_CHIPS = [
  "Beach getaway under ₹50K",
  ...
];
```

### Budget presets
In `BudgetSlider.tsx`, edit the `PRESETS` array:
```tsx
const PRESETS = [
  { label: "Under ₹30K", value: 30000 },
  ...
];
```

### Vibes
In `SmartSearch.tsx`, edit the `VIBES` array — each has its own gradient and
icon. Add more vibes by following the existing pattern.

### Query format
The submit handler builds queries like:
```
"Bali 5 days for 2 people under ₹50k romantic"
```

If you want a different format (e.g., separate URL params), edit the `submit()`
function inside `SmartSearch.tsx`. Right now it routes to:
```
/plan?q=<encoded>
```

Your existing `Plan.tsx` reads `q` from `useSearchParams()` so this works
out of the box.

## Mobile responsiveness

- Input bar stays the same
- Wizard triggers stack vertically below 640px
- Calendar shows one month instead of two on mobile
- Vibe selector goes 2-column instead of 4-column
- Floating panels fill width on mobile

## Animation budget

All transitions use Framer Motion's spring physics with these settings:
- Input glow: 300ms ease
- Wizard expansion: 400ms cubic-bezier(0.22, 1, 0.36, 1)
- Panel open/close: 250ms with subtle scale
- Field updates: 200ms spring

These are tuned to feel premium without lag. Don't lower the durations
below 200ms — micro-interactions need a minimum perceptual time.
